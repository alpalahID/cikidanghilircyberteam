# AutoMBF

$ pkg update && pkg upgrade

$ pkg install python2

$ pip2 install requests

$ pip2 install mechanize

$ pkg install git

$ git clone https://github.com/Fadil-ID/AutoMBF

$ cd AutoMBF

$ python2 AutoMBF.py



download username&password

https://sfile.mobi/8ttp7ARieIc
